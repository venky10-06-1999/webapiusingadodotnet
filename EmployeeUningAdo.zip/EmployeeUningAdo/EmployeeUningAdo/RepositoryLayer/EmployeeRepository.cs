﻿using EmployeeUningAdo.Models;
using System.Data.SqlClient;

namespace EmployeeUningAdo.RepositoryLayer
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly string _connectionString;

        public EmployeeRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

      
        public async Task<Employee> GetEmployeeByIdAsync(int id)
        {
            Employee employee = null;

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                string sql = "SELECT Id, Name, Department, Position, Salary FROM Employees WHERE Id = @Id";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            employee = new Employee
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Department = reader.GetString(2),
                                Position = reader.GetString(3),
                                Salary = reader.GetDecimal(4),
                                // Add other properties similarly
                            };
                        }
                    }
                }
            }

            return employee;
        }

        public async Task AddEmployeeAsync(Employee employee)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                string sql = "INSERT INTO Employees (Name, Department, Position, Salary) VALUES (@Name, @Department, @Position, @Salary)";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@Name", employee.Name);
                    command.Parameters.AddWithValue("@Department", employee.Department);
                    command.Parameters.AddWithValue("@Position", employee.Position);
                    command.Parameters.AddWithValue("@Salary", employee.Salary);
                    // Add other parameters similarly if needed
                    await command.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task UpdateEmployeeAsync(Employee employee)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                string sql = "UPDATE Employees SET Name = @Name, Department = @Department, Position = @Position, Salary = @Salary WHERE Id = @Id";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@Id", employee.Id);
                    command.Parameters.AddWithValue("@Name", employee.Name);
                    command.Parameters.AddWithValue("@Department", employee.Department);
                    command.Parameters.AddWithValue("@Position", employee.Position);
                    command.Parameters.AddWithValue("@Salary", employee.Salary);
                    // Add other parameters similarly if needed
                    await command.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task DeleteEmployeeAsync(int id)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                string sql = "DELETE FROM Employees WHERE Id = @Id";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);
                    await command.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task<IEnumerable<Employee>> GetEmployeesAsync()
        {
            List<Employee> employees = new List<Employee>();

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                string sql = "SELECT Id, Name, Department, Position, Salary FROM Employees";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            employees.Add(new Employee
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Department = reader.GetString(2),
                                Position = reader.GetString(3),
                                Salary = reader.GetDecimal(4),
                                // Add other properties similarly
                            });
                        }
                    }
                }
            }

            return employees;
        }
    }
}

