﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.IdentityModel.Tokens;

class Program
{
    static void Main(string[] args)
    {
        int keySizeInBits = 256; // 256 bits key size for HMAC-SHA256
        string secretKey = "mySuperSecretKey1231111111111111111111111111111111"; // Convert bits to bytes

        Console.WriteLine("Generated Secret Key: " + secretKey);

        // Generate JWT token
        string jwtToken = GenerateJwtToken(secretKey, "MyAuthServer", "MyApiClient", 60); // 60 minutes expiration
        Console.WriteLine("Generated JWT Token: " + jwtToken);
    }

    static string GenerateRandomSecretKey(int keySizeInBytes)
    {
        byte[] keyBytes = new byte[keySizeInBytes];
        using (var rng = RandomNumberGenerator.Create())
        {
            rng.GetBytes(keyBytes);
        }
        return Convert.ToBase64String(keyBytes);
    }

    static string GenerateJwtToken(string secretKey, string issuer, string audience, int expiryMinutes)
    {
        var tokenHandler = new JwtSecurityTokenHandler();
        var key = Encoding.ASCII.GetBytes(secretKey);
        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, "John Doe"), // Add any other claims as needed
                new Claim(ClaimTypes.Role, "Admin")
            }),
            Issuer = issuer,
            Audience = audience,
            Expires = DateTime.UtcNow.AddMinutes(expiryMinutes),
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        };
        var token = tokenHandler.CreateToken(tokenDescriptor);
        return tokenHandler.WriteToken(token);
    }
}
